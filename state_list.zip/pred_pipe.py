import pandas as pd
import numpy as np

from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
#from sklearn.metrics import accuracy_score
import pickle

import xgboost as xgb

sql = False

def sql_bypass(df):
    #df =df[df['CATEGORY_DESC'] == 'LED']
    df['city'] = df['CITY']
    state_data = pd.read_csv('state_list.csv')
    print(state_data.head())
    df = pd.merge(df, state_data, on='city')
    #df_clean = pd.DataFrame()
    df[['customer_id','age','etype','gender', 'maritalstatus', 'state']] = df[['CUSTOMER_ID','AGE','EMPLOYMENTTYPE','GENDER', 'MARITALSTATUS', 'State']]
    df = df.dropna()
    # Binnig age
    g = []
    for elem in range(100):
        if elem % 5 == 0:
            #print(elem)
            g.append(elem)
    df['AgeRange'] = pd.cut(df['age'], g)

    # Getting ceil of age_range
    temp = ''
    a = []
    for i,row in df.iterrows():
        temp = str(row['AgeRange'])
        temp = temp.replace('(','')
        temp = temp.split(',')
        a.append(temp[0])
    df['age_bin'] = a

    df['EMPLOYMENTTYPE'] = df['EMPLOYMENTTYPE'].replace({'SELF EMPLOYED': 'self_employed', 'Self Employed': 'self_employed', 'SELF EMPLOYED PROFESSIONAL': 'self_employed','Self Employed Professional':'self_employed'})
    df['EMPLOYMENTTYPE'] = df['EMPLOYMENTTYPE'].replace({'SALARIED': 'salaried', 'Salaried': 'salaried', 'SAL': 'salaried'})
    df['yyyymm'] = '201805'
    df['yyyy'] = '2018'
    df['mm'] = '05'
    df = df.dropna()
    del df['AgeRange']
    return df

if sql == False:
    print(pd.read_csv('led_disbursements.csv').head())
    df = pd.read_csv('led_disbursements.csv')
    df = sql_bypass(df)
    print(df.head(),df.columns)
    df_pred = pd.DataFrame()
    df_pred[['customer_id','age','etype','gender', 'maritalstatus', 'state']] = df[['CUSTOMER_ID','AGE','EMPLOYMENTTYPE','GENDER', 'MARITALSTATUS', 'State']]
    print(df_pred.head(20))
else:
    df_pred = pd.read('led_sql_process.csv')


del df
df = pd.DataFrame()
df = df_pred.dropna()

df_preds = pd.DataFrame()
df_preds['customer_id'] = df['customer_id']
del df['customer_id']

# One_hotting Data

one_hot = pd.get_dummies(df['etype'])
df = df.drop('etype',axis = 1)
df = df.join(one_hot)

one_hot = pd.get_dummies(df['gender'])
df = df.drop('gender',axis = 1)
df = df.join(one_hot)

one_hot = pd.get_dummies(df['maritalstatus'])
df = df.drop('maritalstatus',axis = 1)
df = df.join(one_hot)

one_hot = pd.get_dummies(df['State'])
df = df.drop('State',axis = 1)
df = df.join(one_hot)

if df.shappe[1] == 33:
    print('Feature Generation complete, Moving forward for predictions')
else:
    print('Please check the columns for feature matrix')


with open('R20.7.model','wb') as f:
    model = pickle.load(f)
with open('R20.7.le','wb') as f:
    le = pickle.load(f)

y_pred = model.predict(df.values)
y_prob  = model.predict_proba(df.values)

tt = []
for v in range(len(y_pred)):
    ec = []
    top_3_idx = np.argsort(y_pred[v])[-3:]
    ec = list(top_3_idx)
    tt.append(ec)

# c = 0
# e = []
# for vv in range(len(tt)):
#     e = tt[vv]
#     for i in range(3):
#         if e[i] == y_test[vv]:
#             c += 1
#             break

df_preds['Reco_1_label'],df_preds['Reco_2_label'],df_preds['Reco_3_label'] = tt.T

df_preds['Reco_1'] = le.inverse_transform(df['Reco_1_label'].values)
df_preds['Reco_1'] = le.inverse_transform(df['Reco_2_label'].values)
df_preds['Reco_1'] = le.inverse_transform(df['Reco_3_label'].values)

del df_preds['Reco_1_label']
del df_preds['Reco_2_label']
del df_preds['Reco_3_label']

df_preds.to_csv('Reco_final_list.csv',index=None)
#test_thing["Probs_HAIER APPLIANCES (INDIA) P.LIMITED"], test_thing["Probs_INTEX"], test_thing["Probs_LG ELECTRONICS INDIA PVT.LTD"] = y_prob.T